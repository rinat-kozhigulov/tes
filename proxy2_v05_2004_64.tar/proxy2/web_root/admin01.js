
$(document).ready( 
	function() {
		reload();
	}
);


function reload() {
	$.ajax({
		type: "GET",
		url: '/admin_params',
		dataType: 'json',
		contentType: "application/json",
		
		success: function(data) {
			console.log("reload success");
			show_admin(data);
		},
		
		error: function (jqXHR, exception) {
			var msg = '';
			var reload = 0;
			if (jqXHR.status === 0) {
				msg = 'Not connect.\n Verify Network.';
			} else if (jqXHR.status == 404) {
				msg = 'Requested page not found. [404]';
			} else if (jqXHR.status == 500) {
				msg = 'Internal Server Error [500].';
			} else if (exception === 'parsererror') {
				msg = 'Requested JSON parse failed.';
				reload = 1;
			} else if (exception === 'timeout') {
				msg = 'Time out error.';
			} else if (exception === 'abort') {
				msg = 'Ajax request aborted.';
			} else {
				msg = 'Uncaught Error.\n' + jqXHR.responseText;
			}
			
			console.log("reload error");
			console.log(reload);
			console.log(msg);
			
			if (reload != 0) {
				window.location.href = "/admin_login.html";
				//window.location.reload(true); 
				console.log("reload fire");
			}			
		},		
	})
};


function show_admin(json) {
//	console.log(json);
	
	$('#host_name').val(json.host_name);
	if (json.host_name == "") {
		var ss = window.location.host;
		var npos = ss.indexOf(":");
		if (npos>0) ss = ss.slice(0, npos);
		$('#host_name').val(ss);
	}
	
	$('#web_port').val(json.web_port);
	
	var web_ssl = 0;
	if (json.web_ssl == '1') web_ssl = 1;
	$('#web_ssl').prop('checked', web_ssl);
	$('#web_ssl').prop('disabled', true);
	
	var web_auth = 0;
	if (json.web_auth == '1') web_auth = 1;
	$('#web_auth').prop('checked', web_auth);
	
	$('#web_user').val(json.web_user);
	$('#web_pass').val(json.web_pass);

	$('#admin_name').val(json.admin_name);
	$('#admin_pass').val(json.admin_pass);

	$('#stat_days').val(json.stat_days);
	$('#logout_time').val(json.logout_time);
	
	
	
};


function send_admin() {

	var host_name = $('#host_name').val();
	var web_port = $('#web_port').val();
	var web_ssl = 0;
	if ($('#web_ssl').is(':checked')) web_ssl = 1;
	var web_auth = 0;
	if ($('#web_auth').is(':checked')) web_auth = 1;
	var web_user = $('#web_user').val();
	var web_pass = $('#web_pass').val();

	var admin_name = $('#admin_name').val();
	var admin_pass = $('#admin_pass').val();

	var stat_days = $('#stat_days').val();
	var logout_time = $('#logout_time').val();

	$.ajax({
		type: "POST",
		url: '/admin_update',
		data: {'host_name': host_name, 'web_port': web_port, 'web_ssl': web_ssl, 'web_auth': web_auth, 'web_user': web_user, 'web_pass': web_pass, 'admin_name': admin_name, 'admin_pass': admin_pass, 'stat_days': stat_days, 'logout_time': logout_time},

	success: function(data) {
		//console.log("success");
	},

	error: function (jqXHR, exception) {
		var msg = '';
		if (jqXHR.status === 0) {
			msg = 'Not connect.\n Verify Network.';
		} else if (jqXHR.status == 404) {
			msg = 'Requested page not found. [404]';
		} else if (jqXHR.status == 500) {
			msg = 'Internal Server Error [500].';
		} else if (exception === 'parsererror') {
			msg = 'Requested JSON parse failed.';
			reload = 1;
		} else if (exception === 'timeout') {
			msg = 'Time out error.';
		} else if (exception === 'abort') {
			msg = 'Ajax request aborted.';
		} else {
			msg = 'Uncaught Error.\n' + jqXHR.responseText;
		}
		console.log(msg);
	},
});
};



