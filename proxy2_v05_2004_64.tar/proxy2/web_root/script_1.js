
$(document).ready( 
	function() {
		//show_url()
		
		req_params();
		//setInterval(req_params, 2000);
	}
);


function show_url() {
//	$('#url_info').text(window.location.host);
};



function req_params() {
  //console.log("req_params");
  
  $.ajax({
    type: "GET",
    url: '/get_params',
	
    //dataType: "text",
	dataType: 'json',
	contentType: "application/json",
    
	success: function(data) {
		console.log("req_params  success");
		show_params(data);
    },

	error: function (jqXHR, exception) {
        var msg = '';
		var reload = 0;
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed.';
			reload = 1;
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
        //$('#post').html(msg);

		console.log(msg);
		
		if (reload != 0) {
			window.location.reload(true); 
		}
    },
  });  
};


function show_params(json) {
	
	$('#dev_sn').text(json.dev_sn);
	
	var dev_con = json.dev_con;
	
	$('#dev_con_status').text(json.dev_con_status);
	
	$('#con_vsend').text(json.con_vsend);
	$('#con_rtsp1').text(json.con_rtsp1);
	$('#con_rtsp2').text(json.con_rtsp2);

	$('#con_vsend_port').text(json.con_vsend_port);
	$('#con_rtsp1_port').text(json.con_rtsp1_port);
	$('#con_rtsp2_port').text(json.con_rtsp2_port);

	$('#con_vsend_link').text(json.con_vsend_link);
	$('#con_rtsp1_link').text(json.con_rtsp1_link);
	$('#con_rtsp2_link').text(json.con_rtsp2_link);

	//====================

	$('#dev_con_t1').text(json.dev_con_t1);
	$('#dev_con_t2').text(json.dev_con_t2);
	
	$('#dev_cfg_cam_1').text(json.dev_cfg_cam_1);
	$('#dev_cfg_cam_2').text(json.dev_cfg_cam_2);
	$('#dev_cfg_pwr_1').text(json.dev_cfg_pwr_1);
	$('#dev_cfg_pwr_2').text(json.dev_cfg_pwr_2);
	
	$('#dev_cfg_lock_1').text(json.dev_cfg_lock_1);
	$('#dev_cfg_lock_2').text(json.dev_cfg_lock_2);
	
	$('#dev_cfg_sd_size_0').text(json.dev_cfg_sd_size_0);
	$('#dev_cfg_sd_size_1').text(json.dev_cfg_sd_size_1);
	$('#dev_cfg_sd_pos_0').text(json.dev_cfg_sd_pos_0);
	$('#dev_cfg_sd_pos_1').text(json.dev_cfg_sd_pos_1);
	$('#dev_cfg_sd_state_0').text(json.dev_cfg_sd_state_0);
	$('#dev_cfg_sd_state_1').text(json.dev_cfg_sd_state_1);
	
	$('#sys_time').text(json.sys_time);
	$('#avr_time').text(json.avr_time);
	
	$('#dev_cfg_time').text(json.dev_cfg_time);
	if ( !dev_con ) {
		$('#dev_cfg_time').css('color', 'red');
	}
	
	$('#proxy_sys_time').text(json.proxy_sys_time);
	

	$('#dev_cfg_rtsp').text(json.dev_cfg_rtsp);
	
	$('input[id=rtsp_br_rate]').val(json.rtsp_br_rate);
	$('input[id=rtsp_br_frac]').val(json.rtsp_br_frac);
	$('input[id=rtsp_br_rate]').change();
	
	if ( dev_con ) {
		$('#rtsp_submit').prop('disabled', false);
		console.log("rtsp disabled false");
		console.log("dev_con=" + dev_con);
	}
	else {
		$('#rtsp_submit').prop('disabled', true);
		console.log("rtsp disabled true");
		console.log("dev_con=" + dev_con);
	}
	
	
};
