


$(document).ready( 
	function() {
	
		//var DD = document.getElementById("log_date");//.value;
		//DD.value = "2018-07-07";		

		req_log();
	}
);


function req_log() {
  console.log("req_log");
  
	var DD = document.getElementById("log_date");//.value;
		//DD.value = json.date;		
	console.log(DD.value);
		
  
  
  $.ajax({
    type: "GET",
    url: '/get_logs',
	dataType: 'text',
	contentType: "application/html",
	//data: {'date' : '2018-02-02'},
	data: {'date' : DD.value},
	
    success: function(data) {
		console.log("req_log  success");
		//console.log(data);
		
		//$('#logs').html( data );
		$('#replace').html( data );
		
		//var DD = document.getElementById("log_date"); //.value;
		//DD.value = json.date;		
		
		//$('#logs').html( json.log );
    },
	
	error: function (jqXHR, exception) {
        var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
		console.log(msg);
    },
  });  
};



